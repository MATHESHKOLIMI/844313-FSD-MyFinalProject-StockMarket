import { Injectable } from '@angular/core';
import {HttpClientModule,HttpClient, HttpRequest, HttpEvent, HttpResponse} from '@angular/common/http';

import { Observable } from 'rxjs';
import { SummaryModel } from 'src/entity/SummaryModel';
import { StockDetails } from './import-stock-data/stockDetails';

type EntityResponseType=HttpResponse<SummaryModel>;
type EntityResponseType1=HttpResponse<StockDetails[]>;
@Injectable({
  providedIn: 'root'
})
export class UploadService {

  constructor(private http: HttpClient) {}

  pushFileToStorage(file: File): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);

    const req = new HttpRequest('POST', 'http://localhost:8094/import', formdata, {
      reportProgress: true,
      responseType: 'text'
    }

    );

    return this.http.request(req);
  }
  getSummary():Observable<EntityResponseType>{
    return this.http.get<SummaryModel>("http://localhost:8094/summary", { observe: 'response' });
 }
 getAllStockDetails():Observable<EntityResponseType1>{
  return this.http.get<StockDetails[]>("http://localhost:8094/stockData", { observe: 'response' });
}
}
