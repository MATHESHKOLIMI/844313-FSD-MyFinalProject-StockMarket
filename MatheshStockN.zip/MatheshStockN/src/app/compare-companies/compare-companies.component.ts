import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compare-companies',
  templateUrl: './compare-companies.component.html',
  styleUrls: ['./compare-companies.component.css']
})
export class CompareCompaniesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  public barChartOptions={ responsive:true};

  public barChartLabels=['2006','2007','2008','2009','2010','2011','2012','2013','2014','2015','2016'];
  public barChartType='bar';
  public barChartLegend=true;

  public barChartData = [
    {data: [28, 48, 40, 19, 86, 27, 90,87,74,54,121,22], label: 'Twitter'},
    {data: [65, 59, 80, 81, 56, 55, 40,87,74,54,21,22], label: 'Google'},
    {data: [23, 44, 13, 19, 86, 65, 90,87,74,54,21,22], label: 'Facebook'}
  ];

}
