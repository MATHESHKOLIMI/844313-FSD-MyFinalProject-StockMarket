import { TestBed } from '@angular/core/testing';

import { UpdatedipoService } from './updatedipo.service';

describe('UpdatedipoService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UpdatedipoService = TestBed.get(UpdatedipoService);
    expect(service).toBeTruthy();
  });
});
