import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatedManageCompanyComponent } from './updated-manage-company.component';

describe('UpdatedManageCompanyComponent', () => {
  let component: UpdatedManageCompanyComponent;
  let fixture: ComponentFixture<UpdatedManageCompanyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatedManageCompanyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatedManageCompanyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
