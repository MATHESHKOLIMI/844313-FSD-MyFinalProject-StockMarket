export interface Company{
    cid:number;
    companyName:string;
    companyTurnOver:number;
    chiefEO:string;
    boardOfDirectors:string;
    stockExchange:string;
    sector:string;
    companyServices:string;
    stockCode:string;
}