import { Component, OnInit } from '@angular/core';
import { UpdatedCompanyService } from '../updated-company.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Company } from './Company';
@Component({
  selector: 'app-updated-manage-company',
  templateUrl: './updated-manage-company.component.html',
  styleUrls: ['./updated-manage-company.component.css']
})
export class UpdatedManageCompanyComponent implements OnInit {

  companies:Company[];
  myForm:FormGroup;

  constructor(public service:UpdatedCompanyService,private router:Router) { }

  ngOnInit() {
    this.service.getAllCompanies().subscribe(data=>{this.companies=data.body
      console.log(this.companies);
    });
    
    console.log(this.companies);

    this.myForm=new FormGroup({
      Cid:new FormControl('',[Validators.required]),
      CompanyName:new FormControl('',[Validators.required]),
      CompanyTurnOver:new FormControl('',[Validators.required]),
      ChiefExecuitiveoficer:new FormControl('',[Validators.required]),
      BoardOfDirectors:new FormControl('',[Validators.required]),
      StockExchange:new FormControl('',[Validators.required]),
      Sector:new FormControl('',[Validators.required]),
      CompanyServices:new FormControl('',[Validators.required]),
      StockCode:new FormControl('',[Validators.required])
      });
  }

  onSubmit(myForm:FormGroup){
    let company:Company={
      cid:myForm.value.Cid,
    companyName:myForm.value.CompanyName,
    companyTurnOver:myForm.value.CompanyTurnOver,
    chiefEO:myForm.value.ChiefExecuitiveoficer,
    boardOfDirectors:myForm.value.BoardOfDirectors,
    stockExchange:myForm.value.StockExchange,
    sector:myForm.value.Sector,
    companyServices:myForm.value.CompanyServices,
    stockCode:myForm.value.StockCode

    }
    console.log(company)
      this.service.saveCompany(company).subscribe(data=>{
        console.log(company);
      })
      this.router.navigate(['/updatedCompanyList'])
  }


}
