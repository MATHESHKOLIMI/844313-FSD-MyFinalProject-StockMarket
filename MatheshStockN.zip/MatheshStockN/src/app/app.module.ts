import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import{HttpClient,HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ContactCreateComponent } from './contact-create/contact-create.component';
import { ContactListComponent } from './contact-list/contact-list.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AdminlandingComponent } from './adminlanding/adminlanding.component';
import { UserlandingComponent } from './userlanding/userlanding.component';
import { LooginComponent } from './loogin/loogin.component';
import {StudentServicesService} from './service/student-services.service'
import { from } from 'rxjs';
import { RegUserComponent } from './reg-user/reg-user.component';
import {ReactiveFormsModule} from '@angular/forms';
import { RegLoginpageComponent } from './reg-loginpage/reg-loginpage.component';
import { ImportStockDataComponent } from './import-stock-data/import-stock-data.component';
import { SummaryStatusComponent } from './summary-status/summary-status.component';
import { CompareCompaniesComponent } from './compare-companies/compare-companies.component';
import {ChartsModule} from 'ng2-charts';
import { ManageCompanyComponent } from './manage-company/manage-company.component';

import { ManageexchangeComponent } from './manageexchange/manageexchange.component';
import { IpodetailsComponent } from './ipodetails/ipodetails.component';
import { CompareSectorComponent } from './compare-sector/compare-sector.component';
import { IposComponent } from './ipos/ipos.component';
import { OthersComponent } from './others/others.component';
import {UpdatedManageCompanyComponent} from './updated-manage-company/updated-manage-company.component';
import { UpdatedIpoInformationComponent } from './updated-ipo-information/updated-ipo-information.component';
import { UpdatedManageExchangeComponent } from './updated-manage-exchange/updated-manage-exchange.component';
import { UpdatedOtheresComponent } from './updated-otheres/updated-otheres.component';
import { LoginComponent } from './login/login.component';
import { UpdatedCompanyListComponent } from './updated-company-list/updated-company-list.component';
import { UpdatedIpoComponent } from './updated-ipo/updated-ipo.component';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ContactCreateComponent,
    ContactListComponent,
    HeaderComponent,
    FooterComponent,
    AdminlandingComponent,
    UpdatedManageCompanyComponent,
    UpdatedIpoInformationComponent,
    UpdatedManageExchangeComponent,
    UserlandingComponent,
    LooginComponent,
    RegUserComponent,
    RegLoginpageComponent,
    ImportStockDataComponent,
    SummaryStatusComponent,
    CompareCompaniesComponent,
    ManageCompanyComponent,
    ManageexchangeComponent,
    IpodetailsComponent,
    CompareSectorComponent,
    IposComponent,
    OthersComponent,
    UpdatedOtheresComponent,
    LoginComponent,
    UpdatedCompanyListComponent,
    UpdatedIpoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,ChartsModule
  ],
  providers: [StudentServicesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
