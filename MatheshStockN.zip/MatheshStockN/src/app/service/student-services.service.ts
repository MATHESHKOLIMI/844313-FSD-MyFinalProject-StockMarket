import { Injectable } from '@angular/core';
import{HttpClient,HttpResponse} from '@angular/common/http';
import{Observable} from 'rxjs';
import{StudentSB} from '../../entity/StudentSB';
import { User } from '../reg-user/user';
import { LoginUser } from 'src/entity/loginUser';

type EntityResponseType=HttpResponse<User[]>;

@Injectable({
  providedIn: 'root'
})
export class StudentServicesService {
  constructor(private http:HttpClient) { }

  getAllUsers():Observable<EntityResponseType>{
    return this.http.get<User[]>("http://localhost:8093/getUsers", { observe: 'response' });
 }

 public saveUser(user:User){
  return this.http.post("http://localhost:8093/saveUser", user, {observe: 'response'});
}
public getUserByMail(mail:string){
  return this.http.get<LoginUser>(mail,{observe:'response'});
}
}
