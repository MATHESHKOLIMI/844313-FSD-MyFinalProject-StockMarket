export interface Ipo{
    id:number;
    companyName:string;
    stockExchange:string;

    pricePerShare:number;
    totalNumberOfShares:number;
    openTimeDate:Date;
    Remarks:string;
}