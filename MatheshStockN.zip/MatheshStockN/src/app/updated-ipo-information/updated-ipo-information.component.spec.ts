import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatedIpoInformationComponent } from './updated-ipo-information.component';

describe('UpdatedIpoInformationComponent', () => {
  let component: UpdatedIpoInformationComponent;
  let fixture: ComponentFixture<UpdatedIpoInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatedIpoInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatedIpoInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
