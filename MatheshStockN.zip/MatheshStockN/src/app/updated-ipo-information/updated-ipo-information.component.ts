import { Component, OnInit } from '@angular/core';
import { Ipo } from './updatedipo';
import { UpdatedipoService } from '../updatedipo.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-updated-ipo-information',
  templateUrl: './updated-ipo-information.component.html',
  styleUrls: ['./updated-ipo-information.component.css']
})
export class UpdatedIpoInformationComponent implements OnInit {

  ipos:Ipo;
  myForm:FormGroup;
  constructor(private service:UpdatedipoService,private router:Router) { }

  ngOnInit() {

    this.myForm=new FormGroup({
      IPOid:new FormControl('',[Validators.required,Validators.minLength(4),Validators.maxLength(8)]),
      CompanyName:new FormControl(''),
      StockExchange:new FormControl(''),
      PreicePerShare:new FormControl(''),
      TotalNumberOfShares:new FormControl(''),
      OpeningDate:new FormControl(''),
      Remarks:new FormControl('')
      });

  }

  onSubmit(myForm:FormGroup){
    let ipo:Ipo={
      id:myForm.value.IPOid,
      companyName:myForm.value.CompanyName,
      stockExchange:myForm.value.StockExchange,
      pricePerShare:myForm.value.PreicePerShare,
      totalNumberOfShares:myForm.value.TotalNumberOfShares,
      openTimeDate:myForm.value.OpeningDate,
      Remarks:myForm.value.Remarks

    }
    console.log(ipo)
      this.service.saveIpos(ipo).subscribe(data=>{
        console.log(ipo);
      })
      this.router.navigate(['/updatedIPO'])
  }


    
}
