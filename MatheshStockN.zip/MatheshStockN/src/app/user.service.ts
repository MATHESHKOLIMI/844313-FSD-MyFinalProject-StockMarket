import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {HttpResponse} from '@angular/common/http';
import { Observable } from 'rxjs';

//type EntityResponseType = HttpResponse<UserModel[]>;
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }

  // getUsers():Observable<EntityResponseType>{
  //       //return this.http.get<StudentModel[]>("http://localhost:8084/students", {observe: 'response'});
  //       return this.http.get<UserModel[]>("http://localhost:8093/getUsers", {observe: 'response'});
  // }

  // save(userModel:UserModel){
  //      return this.http.post<UserModel>("http://localhost:8093/saveUser", userModel, {observe: 'response'});
  // }
}
