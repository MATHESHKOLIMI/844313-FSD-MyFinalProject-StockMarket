import { Component, OnInit } from '@angular/core';
import { Ipo } from '../updated-ipo-information/updatedipo';
import { UserService } from '../user.service';
import { UpdatedipoService } from '../updatedipo.service';

@Component({
  selector: 'app-updated-ipo',
  templateUrl: './updated-ipo.component.html',
  styleUrls: ['./updated-ipo.component.css']
})
export class UpdatedIpoComponent implements OnInit {
  ipo:Ipo[];
  constructor(private service:UpdatedipoService) { }

  ngOnInit() {
    this.service.getIpos().subscribe(data=>{
      this.ipo=data.body;
    })
  }

}
