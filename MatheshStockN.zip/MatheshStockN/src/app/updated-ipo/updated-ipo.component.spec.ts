import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatedIpoComponent } from './updated-ipo.component';

describe('UpdatedIpoComponent', () => {
  let component: UpdatedIpoComponent;
  let fixture: ComponentFixture<UpdatedIpoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatedIpoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatedIpoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
