import { Component, OnInit,Input } from '@angular/core';
import { LoginUser } from 'src/entity/loginUser';
import { StudentServicesService } from '../service/student-services.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { StudentSB } from 'src/entity/StudentSB';
import { User } from '../reg-user/user';
import { Router } from '@angular/router';



@Component({
  selector: 'app-reg-loginpage',
  templateUrl: './reg-loginpage.component.html',
  styleUrls: ['./reg-loginpage.component.css']
})
export class RegLoginpageComponent implements OnInit {
  
  user:LoginUser;
  loginUserForm:FormGroup;
  UserName:string;
  constructor(private service:StudentServicesService,private router:Router) { }

  ngOnInit() {
    this.loginUserForm=new FormGroup({
      Email:new FormControl('',[Validators.required,Validators.email]),
      Password:new FormControl('')
    });
  }
  onSubmit(loginUserForm:FormGroup){
    let loginUser1:LoginUser={
      mail:loginUserForm.value.Email,
      password:loginUserForm.value.Password,
      
    }
    let url:string="http://localhost:8093/userByMail/"+loginUser1.mail;
      this.service.getUserByMail(url).subscribe(data=>{
        
        this.user=data.body;
        console.log(this.user);
        if(this.user[0].password===loginUserForm.value.Password){
          if(this.user[0].loginType=='admin'){
            alert("admin login Successfull");
          this.router.navigate(['/admin']);
          }
          else{
            alert("user login Successfull");
            this.router.navigate(['/user'])
          }
          
        }
        else{
          alert("login Unsuccess");
        }
  });
  }

}
