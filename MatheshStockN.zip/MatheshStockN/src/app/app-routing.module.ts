import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactListComponent } from './contact-list/contact-list.component';
import { ContactCreateComponent } from './contact-create/contact-create.component';
import { HomeComponent } from './home/home.component';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { AdminlandingComponent } from './adminlanding/adminlanding.component';
import { UserlandingComponent } from './userlanding/userlanding.component';
import { NONE_TYPE } from '@angular/compiler/src/output/output_ast';
import { RegUserComponent } from './reg-user/reg-user.component';
import { RegLoginpageComponent } from './reg-loginpage/reg-loginpage.component';
import { ImportStockDataComponent } from './import-stock-data/import-stock-data.component';
import { SummaryStatusComponent } from './summary-status/summary-status.component';
import { CompareCompaniesComponent } from './compare-companies/compare-companies.component';
import {ChartsModule} from 'ng2-charts';
import { ManageCompanyComponent } from './manage-company/manage-company.component';
import { UpdatedManageCompanyComponent } from './updated-manage-company/updated-manage-company.component';
import { UpdatedIpoInformationComponent } from './updated-ipo-information/updated-ipo-information.component';
import {UpdatedManageExchangeComponent} from './updated-manage-exchange/updated-manage-exchange.component';
import { UpdatedIpoComponent } from './updated-ipo/updated-ipo.component';
import { CompareSectorComponent } from './compare-sector/compare-sector.component';
import { LoginComponent } from './login/login.component';
import { UpdatedCompanyListComponent } from './updated-company-list/updated-company-list.component';
import { OthersComponent } from './others/others.component';
import { UpdatedOtheresComponent } from './updated-otheres/updated-otheres.component';
const routes: Routes = [
  // // {path:"",component:RegLoginpageComponent},
  // {path:"",component:UpdatedManageCompanyComponent},
  {path:"",component:UpdatedIpoInformationComponent},
  {path:"login",component:LoginComponent},
  {path:"other",component:UpdatedOtheresComponent},
  {path:"userIpo",component:UpdatedIpoComponent},
  {path:"ipoInfromation",component:UpdatedIpoInformationComponent},
  {path:"manageCompany",component:UpdatedManageCompanyComponent},
  {path:"import",component:ImportStockDataComponent},
  {path:"updatedCompanyList",component:UpdatedCompanyListComponent},
  {path:"manageExchange",component:UpdatedManageExchangeComponent},
  {path:"compareCompany",component:CompareCompaniesComponent},
  {path:"compareSector",component:CompareSectorComponent},
  {path:"SummaryStatus",component:SummaryStatusComponent},
  {path:"UserLogin",component:RegLoginpageComponent},
  {path:"RegUser",component:RegUserComponent},
  {path:"home",component:HomeComponent},
  {path:"user",component:UserlandingComponent},
  {path:"admin",component:AdminlandingComponent},
  {path: "home", component: HomeComponent},
  {path: "contact-create", component: ContactCreateComponent},
  {path: "contact-list", component: ContactListComponent}  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule,ChartsModule]
})
export class AppRoutingModule { }
