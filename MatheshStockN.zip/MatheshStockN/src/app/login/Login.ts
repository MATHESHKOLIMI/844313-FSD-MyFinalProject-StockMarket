export interface LoginModel{
    FirstName:string;
    LastName:string;
    MobileNo:number;
    email:string;

}