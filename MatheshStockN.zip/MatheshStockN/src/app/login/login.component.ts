import { Component, OnInit } from '@angular/core';
import { LoginModel } from './Login';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userForm:LoginModel;
  constructor() { }

  ngOnInit() {
    
  }
  create(User:LoginModel){
    console.log(this.userForm.FirstName);

  }

}
