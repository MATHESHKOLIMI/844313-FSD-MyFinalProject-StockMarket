import { Component, OnInit } from '@angular/core';
import {StudentSB} from '../../entity/StudentSB';
import { FormGroup, FormControl, Validators, FormBuilder }  from '@angular/forms';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {StudentServicesService} from '../service/student-services.service';

import {User} from './user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reg-user',
  templateUrl: './reg-user.component.html',
  styleUrls: ['./reg-user.component.css']
})
export class RegUserComponent implements OnInit {
  myForm: FormGroup;
  user2:User[];
  constructor(private service:StudentServicesService, private rou:Router){  }
  
  ngOnInit(): void {
    
    // {
    //   this.service.getAllUsers().subscribe(data=>{
    //     this.user2=data.body
    //   })
      
    // }
    
    this.myForm=new FormGroup({
      UserName:new FormControl('',[Validators.required,Validators.minLength(8)]),
      Password:new FormControl('',[Validators.required]),
      Email:new FormControl('',[Validators.required,Validators.email]),
      LoginType:new FormControl('',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]),
      MobileNo:new FormControl('',[Validators.required])
      });
    }
  
  onSubmit(myForm:FormGroup){
    let user1:User={
      userName:myForm.value.UserName,
      password:myForm.value.Password,
      mobileNumber:myForm.value.MobileNo,
      email:myForm.value.Email,
      loginType:myForm.value.LoginType
    }
    this.service.saveUser(user1).subscribe(data =>{
      console.log(user1);
    });

    this.rou.navigate(['/UserLogin'])
  }
}
