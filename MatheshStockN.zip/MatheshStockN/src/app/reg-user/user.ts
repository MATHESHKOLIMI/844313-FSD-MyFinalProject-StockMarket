export interface User{
    uid?:number;
    userName:string;
    password:string;
    email:string;
    mobileNumber:number;
    loginType:string;
}