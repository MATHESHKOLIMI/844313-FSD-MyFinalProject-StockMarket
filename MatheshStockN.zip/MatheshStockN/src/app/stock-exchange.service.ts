import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {HttpResponse} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Exchange } from './updated-manage-exchange/Exchange';


type EntityResponseType = HttpResponse<Exchange[]>;

@Injectable({
  providedIn: 'root'
})
export class StockExchangeService {

  constructor(private http:HttpClient) { }
  getAllExchanges():Observable<EntityResponseType>{
    return this.http.get<Exchange[]>("http://localhost:9096/getAllExchanges", {observe: 'response'});
  }
}
