import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatedCompanyListComponent } from './updated-company-list.component';

describe('UpdatedCompanyListComponent', () => {
  let component: UpdatedCompanyListComponent;
  let fixture: ComponentFixture<UpdatedCompanyListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatedCompanyListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatedCompanyListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
