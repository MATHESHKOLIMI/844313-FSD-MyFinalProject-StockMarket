import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../company.service';
import { UpdatedCompanyService } from '../updated-company.service';
import { Company } from 'src/entity/Company';

@Component({
  selector: 'app-updated-company-list',
  templateUrl: './updated-company-list.component.html',
  styleUrls: ['./updated-company-list.component.css']
})
export class UpdatedCompanyListComponent implements OnInit {
  companies:Company[];
  company:Company;
  constructor(private service:UpdatedCompanyService) { }

  ngOnInit() {
    this.service.getAllCompanies().subscribe(data=>{
      this.companies=data.body;
    })
  }
  delete(stockCode){
    this.service.deleteCompany(stockCode).subscribe(data=>{
      
    })
  }

}
