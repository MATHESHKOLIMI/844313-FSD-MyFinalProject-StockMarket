import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpResponse, HttpEventType } from '@angular/common/http';
import { UploadService } from '../upload.service';
import { Router } from '@angular/router';
import { SummaryModel } from 'src/entity/SummaryModel';
import { StockDetails } from './stockDetails';

@Component({
  selector: 'app-import-stock-data',
  templateUrl: './import-stock-data.component.html',
  styleUrls: ['./import-stock-data.component.css']
})
export class ImportStockDataComponent implements OnInit  {

  selectedFiles: FileList;
  stockDetails:StockDetails[];
  currentFileUpload: File;
   constructor(private router:Router, private uploadService: UploadService) {}
  ngOnInit(): void {
    this.uploadService.getAllStockDetails().subscribe(data=>this.stockDetails=data.body)
  }
 selectFile(event) {
   this.selectedFiles = event.target.files;
 }
 upload() {

   this.currentFileUpload = this.selectedFiles.item(0);
   this.uploadService.pushFileToStorage(this.currentFileUpload).subscribe(event => {
    if (event instanceof HttpResponse) {
       console.log('File is completely uploaded!');
     }

     this.router.navigate(['/SummaryStatus'])
   });

   this.selectedFiles = undefined;
 }

}
