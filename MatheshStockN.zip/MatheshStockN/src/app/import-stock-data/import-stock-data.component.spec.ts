import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportStockDataComponent } from './import-stock-data.component';

describe('ImportStockDataComponent', () => {
  let component: ImportStockDataComponent;
  let fixture: ComponentFixture<ImportStockDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportStockDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportStockDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
