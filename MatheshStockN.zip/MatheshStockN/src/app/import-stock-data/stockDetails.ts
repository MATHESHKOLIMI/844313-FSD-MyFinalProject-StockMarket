import { Time } from '@angular/common';

export interface StockDetails{
    companyCode:string,
    stockExchange:string,
    pricePerShar:number,
    date:Date,
    time:Time
}