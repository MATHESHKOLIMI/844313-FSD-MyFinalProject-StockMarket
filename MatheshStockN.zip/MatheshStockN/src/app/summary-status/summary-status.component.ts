import { Component, OnInit } from '@angular/core';
import {SummaryModel} from '../../entity/SummaryModel';
import { UploadService } from '../upload.service';
@Component({
  selector: 'app-summary-status',
  templateUrl: './summary-status.component.html',
  styleUrls: ['./summary-status.component.css']
})
export class SummaryStatusComponent implements OnInit {
  sm:SummaryModel;
  // selectedFiles: FileList;
  // stockDetails:StockDetails[];
  // currentFileUpload: File;
  //  constructor(private router:Router, private uploadService: UploadService) {}
  // ngOnInit(): void {
  //   this.uploadService.getAllStockDetails().subscribe(data=>this.stockDetails=data.body)
  // }
  constructor(private service:UploadService) { }

  ngOnInit() {
    this.service.getSummary().subscribe(data=>{
      this.sm=data.body;
      console.log(data.body)
    })
  }

}
