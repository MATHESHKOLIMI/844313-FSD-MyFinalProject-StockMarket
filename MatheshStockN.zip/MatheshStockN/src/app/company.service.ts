import { Injectable } from '@angular/core';

import{HttpClient,HttpResponse} from '@angular/common/http';
import{Observable} from 'rxjs';
import { Company } from 'src/entity/Company';

type EntityResponseType=HttpResponse<Company[]>;
@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  constructor(private http:HttpClient) { }
  getAllCompanies():Observable<EntityResponseType>{
    return this.http.get<Company[]>("http://localhost:8095/getCompanies", { observe: 'response' });
 }

 public saveCompany(company:Company){
  return this.http.post("http://localhost:8095/saveCompany", company, {observe: 'response'});
}
}
