import { TestBed } from '@angular/core/testing';

import { UpdatedCompany1Service } from './updated-company1.service';

describe('UpdatedCompany1Service', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UpdatedCompany1Service = TestBed.get(UpdatedCompany1Service);
    expect(service).toBeTruthy();
  });
});
