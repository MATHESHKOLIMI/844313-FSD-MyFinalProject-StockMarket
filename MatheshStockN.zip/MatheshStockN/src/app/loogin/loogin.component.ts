import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loogin',
  templateUrl: './loogin.component.html',
  styleUrls: ['./loogin.component.css']
})
export class LooginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
