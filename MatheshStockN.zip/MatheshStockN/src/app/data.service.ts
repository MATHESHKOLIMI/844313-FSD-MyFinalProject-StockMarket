import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  contacts = [
    {id: 1, name: "IRCTC", description: "Contact 001 des", email: "ircts.ofcl@email.com"},
    {id: 2, name: "ICICI", description: "Contact 002 des", email: "icici.ofcl@email.com"},
    {id: 3, name: "DMART", description: "Contact 003 des", email: "dmart.ofcl@email.com"},
    {id: 4, name: "DLF", description: "Contact 004 des", email: "dlf.ofcl@email.com"}
  ];

  constructor() { }

  public getContacts():Array<{id, name, description, email}>{
    return this.contacts;
  }
  public createContact(contact: {id, name, description, email}){
    this.contacts.push(contact);
  }
}
