import { Component, OnInit } from '@angular/core';
import { Exchange } from './Exchange';
import { StockExchangeService } from '../stock-exchange.service';

@Component({
  selector: 'app-updated-manage-exchange',
  templateUrl: './updated-manage-exchange.component.html',
  styleUrls: ['./updated-manage-exchange.component.css']
})
export class UpdatedManageExchangeComponent implements OnInit {
  exchanges:Exchange[];
  constructor(private service:StockExchangeService) { }

  ngOnInit() {
    this.service.getAllExchanges().subscribe(data=>{
      this.exchanges=data.body;
    })
  }

}
