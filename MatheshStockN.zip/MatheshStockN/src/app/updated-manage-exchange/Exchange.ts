export interface Exchange{
    seid:number;
    stockExchange:string;
    brief:string;
    remarks:string;
}