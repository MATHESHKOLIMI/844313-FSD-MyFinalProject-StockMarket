import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatedManageExchangeComponent } from './updated-manage-exchange.component';

describe('UpdatedManageExchangeComponent', () => {
  let component: UpdatedManageExchangeComponent;
  let fixture: ComponentFixture<UpdatedManageExchangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatedManageExchangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatedManageExchangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
