import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageexchange',
  templateUrl: './manageexchange.component.html',
  styleUrls: ['./manageexchange.component.css']
})
export class ManageexchangeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
