import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updated-otheres',
  templateUrl: './updated-otheres.component.html',
  styleUrls: ['./updated-otheres.component.css']
})
export class UpdatedOtheresComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
