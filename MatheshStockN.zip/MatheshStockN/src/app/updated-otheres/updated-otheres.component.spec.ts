import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatedOtheresComponent } from './updated-otheres.component';

describe('UpdatedOtheresComponent', () => {
  let component: UpdatedOtheresComponent;
  let fixture: ComponentFixture<UpdatedOtheresComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatedOtheresComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatedOtheresComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
