import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updated-compare-sectors',
  templateUrl: './updated-compare-sectors.component.html',
  styleUrls: ['./updated-compare-sectors.component.css']
})
export class UpdatedCompareSectorsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
