import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatedCompareSectorsComponent } from './updated-compare-sectors.component';

describe('UpdatedCompareSectorsComponent', () => {
  let component: UpdatedCompareSectorsComponent;
  let fixture: ComponentFixture<UpdatedCompareSectorsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatedCompareSectorsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatedCompareSectorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
