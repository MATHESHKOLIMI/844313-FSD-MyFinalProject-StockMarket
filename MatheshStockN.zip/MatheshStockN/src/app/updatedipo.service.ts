import { Injectable } from '@angular/core';

import{HttpClient,HttpResponse} from '@angular/common/http';
import{Observable} from 'rxjs';
import { Ipo } from './updated-ipo-information/updatedipo';

type EntityResponseType=HttpResponse<Ipo[]>;
@Injectable({
  providedIn: 'root'
})
export class UpdatedipoService {

  constructor(private http:HttpClient) { }
  getIpos():Observable<EntityResponseType>{
    return this.http.get<Ipo[]>("http://localhost:8097/getIpos", { observe: 'response' });
 }

 public saveIpos(ipo:Ipo){
  return this.http.post("http://localhost:8097/saveIpos", ipo, {observe: 'response'});
}
}
