import { TestBed } from '@angular/core/testing';

import { UpdatedCompanyService } from './updated-company.service';

describe('UpdatedCompanyService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UpdatedCompanyService = TestBed.get(UpdatedCompanyService);
    expect(service).toBeTruthy();
  });
});
