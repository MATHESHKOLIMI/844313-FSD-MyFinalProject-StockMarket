import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../company.service';
import { Company } from 'src/entity/Company';

@Component({
  selector: 'app-manage-company',
  templateUrl: './manage-company.component.html',
  styleUrls: ['./manage-company.component.css']
})
export class ManageCompanyComponent implements OnInit {

  companies:Company[];

  constructor(public service:CompanyService) { }

  ngOnInit() {
    this.service.getAllCompanies().subscribe(data=>{this.companies=data.body});
    
    console.log(this.companies);
  }

  createContact(formData:any){
    let company:Company={
      cid:formData.value.Cid,
    companyName:formData.value.CompanyName,
    companyTurnOver:formData.value.CompanyTurnOver,
    chiefEO:formData.value.ChiefEO,
    boardOfDirectors:formData.value.BoardOfDirectors,
    stockExchange:formData.value.StockExchange,
    sector:formData.value.Sector,
    companyServices:formData.value.CompanyServices,
    stockCode:formData.value.StockCode

    }
      this.service.saveCompany(company).subscribe(data=>{
        console.log(company);
      })
  }

}
