export interface StudentSB{
    uid?:number;
    firstName:string;
    lastName:string;
    mobileNO:number;
    mail:string;
}