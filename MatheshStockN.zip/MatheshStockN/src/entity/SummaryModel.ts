export interface SummaryModel{
    companyCode:string,
    stockExchange:string,
    numberOfRecords:number,
    fromDate:Date,
    toDate:Date,
}