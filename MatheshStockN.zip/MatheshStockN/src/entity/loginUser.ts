export interface LoginUser{
    uid?:number;
    mail:string;
    password:string;
}