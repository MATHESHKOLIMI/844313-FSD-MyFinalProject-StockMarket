package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Ipo;
import com.example.demo.repo.IpoRepo;

@Service
@Transactional
public class IpoService {
	@Autowired
	IpoRepo ipo;
	
	public List<Ipo> getAllIpoS(){
		return (List<Ipo>)ipo.findAll();
	}
	
	public void saveIpo(Ipo ipo1) {
		ipo.save(ipo1);
	}
}
