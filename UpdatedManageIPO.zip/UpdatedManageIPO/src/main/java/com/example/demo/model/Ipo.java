package com.example.demo.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ipo")
public class Ipo {
	@Id
	int id;
	String companyName;
	String stockExchange;
	double pricePerShare;
	long totalNumberOfShares;
	Date openTimeDate;
	String Remarks;
	public Ipo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Ipo(int id, String companyName, String stockExchange, double pricePerShare, long totalNumberOfShares,
			Date openTimeDate, String remarks) {
		super();
		this.id = id;
		this.companyName = companyName;
		this.stockExchange = stockExchange;
		this.pricePerShare = pricePerShare;
		this.totalNumberOfShares = totalNumberOfShares;
		this.openTimeDate = openTimeDate;
		Remarks = remarks;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getStockExchange() {
		return stockExchange;
	}
	public void setStockExchange(String stockExchange) {
		this.stockExchange = stockExchange;
	}
	public double getPricePerShare() {
		return pricePerShare;
	}
	public void setPricePerShare(double pricePerShare) {
		this.pricePerShare = pricePerShare;
	}
	public long getTotalNumberOfShares() {
		return totalNumberOfShares;
	}
	public void setTotalNumberOfShares(long totalNumberOfShares) {
		this.totalNumberOfShares = totalNumberOfShares;
	}
	public Date getOpenTimeDate() {
		return openTimeDate;
	}
	public void setOpenTimeDate(Date openTimeDate) {
		this.openTimeDate = openTimeDate;
	}
	public String getRemarks() {
		return Remarks;
	}
	public void setRemarks(String remarks) {
		Remarks = remarks;
	}
	@Override
	public String toString() {
		return "Ipo [id=" + id + ", companyName=" + companyName + ", stockExchange=" + stockExchange
				+ ", pricePerShare=" + pricePerShare + ", totalNumberOfShares=" + totalNumberOfShares
				+ ", openTimeDate=" + openTimeDate + ", Remarks=" + Remarks + "]";
	}
	
	
	
	
}
