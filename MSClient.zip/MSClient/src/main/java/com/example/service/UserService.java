package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.model.User;
import com.example.repository.UserRepository;

@Service
@Transactional
public class UserService {
	@Autowired
	UserRepository ur;
	
	public List<User> getAllUser(){
		return (List<User>) ur.findAll();
	}
	public void saveUser(@RequestBody User u) {
		ur.save(u);
	}
}
