package com.example.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="UserReg")
public class User {
	@Column(name="Uid")
	int Uid;
	
	@Column(name="Fname")
	int Fname;

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(int uid, int fname) {
		super();
		Uid = uid;
		Fname = fname;
	}

	public int getUid() {
		return Uid;
	}

	public void setUid(int uid) {
		Uid = uid;
	}

	public int getFname() {
		return Fname;
	}

	public void setFname(int fname) {
		Fname = fname;
	}

	@Override
	public String toString() {
		return "User [Uid=" + Uid + ", Fname=" + Fname + "]";
	}
	
	
}
