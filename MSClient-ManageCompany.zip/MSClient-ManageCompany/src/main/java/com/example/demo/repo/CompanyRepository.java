package com.example.demo.repo;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Company;

public interface CompanyRepository extends CrudRepository<Company, Long>{

		public void deleteByStockCode(String stockCode);

}
