package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Company;
import com.example.demo.repo.CompanyRepository;

@Service
@Transactional
public class CompanyService {
	@Autowired
	CompanyRepository companyRepository;
	
	public List<Company> getAllCompanies(){
		return (List<Company>)companyRepository.findAll();
	}
	
	public void saveCompany(Company company) {
		companyRepository.save(company);
	}

	public void deleteCompany(String stockCode) {
		companyRepository.deleteByStockCode(stockCode);
	}
}
