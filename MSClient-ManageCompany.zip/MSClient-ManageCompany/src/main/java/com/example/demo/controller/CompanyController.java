package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Company;
import com.example.demo.service.CompanyService;

@RestController
@CrossOrigin(origins = "http://localhost:4200",maxAge = 3600)
public class CompanyController {
	@Autowired
	CompanyService companyService;
	
	@GetMapping("/getAllCompanyDetails")
	public List<Company> getAllCompanyDetails() {
		return companyService.getAllCompanies();
	}
	
	@PostMapping("/saveCompany")
	public void saveCompanyDetails(@RequestBody Company comp) {
		companyService.saveCompany(comp);
	}
	
	@RequestMapping(value="/deleteCompany/{stockCode}",method=RequestMethod.DELETE)
	public void deleteCompanyDetails(@PathVariable String stockCode ) {
		companyService.deleteCompany(stockCode);
	}
}
