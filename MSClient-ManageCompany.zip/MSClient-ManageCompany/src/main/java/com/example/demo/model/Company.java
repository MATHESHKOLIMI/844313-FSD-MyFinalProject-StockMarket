package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="companyfinalu")
public class Company {
	int cid;
	String companyName;
	double CompanyTurnOver;
	String chiefEO;
	String boardOfDirectors;
	String stockExchange;
	String sector;
	String companyServices;
	@Id
	String stockCode;
	public Company() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Company(int cid, String companyName, double companyTurnOver, String chiefEO, String boardOfDirectors,
			String stockExchange, String sector, String companyServices, String stockCode) {
		super();
		this.cid = cid;
		this.companyName = companyName;
		CompanyTurnOver = companyTurnOver;
		this.chiefEO = chiefEO;
		this.boardOfDirectors = boardOfDirectors;
		this.stockExchange = stockExchange;
		this.sector = sector;
		this.companyServices = companyServices;
		this.stockCode = stockCode;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public double getCompanyTurnOver() {
		return CompanyTurnOver;
	}
	public void setCompanyTurnOver(double companyTurnOver) {
		CompanyTurnOver = companyTurnOver;
	}
	public String getChiefEO() {
		return chiefEO;
	}
	public void setChiefEO(String chiefEO) {
		this.chiefEO = chiefEO;
	}
	public String getBoardOfDirectors() {
		return boardOfDirectors;
	}
	public void setBoardOfDirectors(String boardOfDirectors) {
		this.boardOfDirectors = boardOfDirectors;
	}
	public String getStockExchange() {
		return stockExchange;
	}
	public void setStockExchange(String stockExchange) {
		this.stockExchange = stockExchange;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getCompanyServices() {
		return companyServices;
	}
	public void setCompanyServices(String companyServices) {
		this.companyServices = companyServices;
	}
	public String getStockCode() {
		return stockCode;
	}
	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}
	@Override
	public String toString() {
		return "Company [cid=" + cid + ", companyName=" + companyName + ", CompanyTurnOver=" + CompanyTurnOver
				+ ", chiefEO=" + chiefEO + ", boardOfDirectors=" + boardOfDirectors + ", stockExchange=" + stockExchange
				+ ", sector=" + sector + ", companyServices=" + companyServices + ", stockCode=" + stockCode + "]";
	}
	
	
	
	
}
