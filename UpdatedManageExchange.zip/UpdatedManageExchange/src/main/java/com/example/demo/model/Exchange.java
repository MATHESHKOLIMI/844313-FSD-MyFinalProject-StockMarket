package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="stockExchange")
public class Exchange {
	
	int seid;
	@Id
	String stockExchange;
	String brief;  
	String remarks;
	public Exchange() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Exchange(int seid, String stockExchange, String brief, String remarks) {
		super();
		this.seid = seid;
		this.stockExchange = stockExchange;
		this.brief = brief;
		this.remarks = remarks;
	}
	public int getSeid() {
		return seid;
	}
	public void setSeid(int seid) {
		this.seid = seid;
	}
	public String getStockExchange() {
		return stockExchange;
	}
	public void setStockExchange(String stockExchange) {
		this.stockExchange = stockExchange;
	}
	public String getBrief() {
		return brief;
	}
	public void setBrief(String brief) {
		this.brief = brief;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "Exchange [seid=" + seid + ", stockExchange=" + stockExchange + ", brief=" + brief + ", remarks="
				+ remarks + "]";
	}
	
	

}
