package com.example.demo.repo;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Exchange;

public interface ExchangeRepo extends CrudRepository<Exchange, Long>{

}
